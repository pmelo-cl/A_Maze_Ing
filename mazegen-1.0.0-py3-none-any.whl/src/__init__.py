from .MazeGenerator import MazeGenerator, Cell

__version__ = "1.0.0"
__all__ = ["MazeGenerator", "Cell"]
